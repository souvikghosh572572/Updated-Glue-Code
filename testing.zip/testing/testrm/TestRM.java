package testing.testrm;
//package com.ehelpy.brihaspati4.testgc;
//Glue Code Pseudo Code:

//  Authentication Manager = am
//  Communication Manager = cm
//  Indexing Manager = im
//  Routing Manager = rm
//  Web Server Module = ws
//  Web Module = web
//  VoIP = voip
//  DFS = dfs
//  UFS = ufs
//  Mail = mail
//  Message = sms

//import the required packages...
import testing.testgc.TestGC;
import java.util.*;
import java.util.LinkedList;
import java.lang.reflect.*;
//import com.ehelpy.brihaspati4.GC.ModuleCheck;  XXXXXXXXXXXX
//import com.ehelpy.brihaspati4.DFS.DFSUI;
//import com.ehelpy.brihaspati4.DFS.Save_Retrive_data_Structures;
/*import com.ehelpy.brihaspati4.comnmgr.CommunicationManager;
import com.ehelpy.brihaspati4.comnmgr.NATHandler;
import com.ehelpy.brihaspati4.comnmgr.NATServer;
import com.ehelpy.brihaspati4.indexmanager.IndexManagement;
import com.ehelpy.brihaspati4.indexmanager.IndexManagementUtilityMethods;
import com.ehelpy.brihaspati4.overlaymgmt.OverlayManagement;
*/
//import com.ehelpy.brihaspati4.routingmgmt.RMThreadPrimary;
//import com.ehelpy.brihaspati4.routingmgmt.SysOutCtrl;
//import com.ehelpy.brihaspati4.routingmgmt.UpdateIP;
//import com.ehelpy.brihaspati4.voip.B4services;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
/*
import com.ehelpy.brihaspati4.testgc.CommMgr;
import com.ehelpy.brihaspati4.testgc.RoutingMgr;
import com.ehelpy.brihaspati4.authenticate.emailid;
import com.ehelpy.brihaspati4.authenticate.Config;
import com.ehelpy.brihaspati4.authenticate.GlobalObject;
import com.ehelpy.brihaspati4.authenticate.dateTimeCheck;
import com.ehelpy.brihaspati4.authenticate.Gui;
import com.ehelpy.brihaspati4.authenticate.Integrity;
import com.ehelpy.brihaspati4.authenticate.GenerateCertificate2;
import com.ehelpy.brihaspati4.authenticate.createConnection;
import com.ehelpy.brihaspati4.authenticate.debug_level;
import com.ehelpy.brihaspati4.authenticate.ReadVerifyCert;
import com.ehelpy.brihaspati4.authenticate.CertificateSignature;

//import com.ehelpy.brihaspati4.indexmanager.IndexingManager;

import com.ehelpy.brihaspati4.routingmgmt.RoutingManager;
*/
//import com.ehelpy.brihaspati4.DFS.dfs3Mgr.DFS3Config;
//import com.ehelpy.brihaspati4.simulateGC.init.DFSInit;

//import com.ehelpy.brihaspati4.simulateGC.IM.Testing;


public class TestRM {
//Start thread of Routing Manager.
//Start thread of Communication Manager.

    //private String final_query;
    //Example: private static ConfigData config;
    //         config = ConfigData.getInstance();

    //final_query = ModuleCheck.findModuleName(qname);
    //Call the final query...
/*
    private int status_skip_flag_rm = 1;
    private int status_skip_flag_cm = 1;

    private int current_skip_flag_rm = 1;
    private int current_skip_flag_cm = 1;

    private int max_limit_of_skip_flags = 32;
    private int count = 0;
*/
    //private String[] module_acronyms = {"am", "cm", "im", "rm", "ws", "web", "voip", "dfs", "ufs", "mail", "sms"};

    // inputModule_buffer_outputModule
    //private LinkedList gc_buffer_am = new LinkedList();
    // here cm and rm sent the data to gc
    public static TestGC gc = new TestGC();
    private static LinkedList rm_buffer_gc = new LinkedList();

    // gc.addMessage_gc_buffer(rm, list_variable)


    // public addMessage_gc_buffer(String source_module_acronym, List message)
    // {
    //     String =
    //     gc_buffer_{source_module_acronym}.add(message);
    // }

    // gc.addMessage_gc_buffer_rm(list_variable)
    public static LinkedList display_rm_buffer_gc()
    {
        LinkedList list2 = rm_buffer_gc;
        return (list2);
    }
    public static void get_gc_instance(TestGC var)
    {
        gc = var;
    }
    public static void sendResponse_gc_buffer_rm()
    {
        List pqr = new ArrayList();
        pqr = (ArrayList)rm_buffer_gc.get(0);
        System.out.println("\nTemp Var: " + pqr + "\n");
        //String pqr_02 = (String)pqr.get(0);
        pqr.set(0, "res");
        pqr.set(2, pqr.get(1));
        pqr.set(1, "rm");
        pqr.add("TLV Format of the Response of the query");
        System.out.println("\nTemp Var: " + pqr + "\n");
        //display_buffer_status();
        System.out.println("Response being sent to gc.");
        gc.addMessage_gc_buffer_rm(pqr);
        System.out.println("Response already received by gc.");
        //display_buffer_status();
    }
    public static void addMessage_rm_buffer_gc(List gcMessage)
    {
        rm_buffer_gc.add(gcMessage);
        System.out.println("List received by RM's input buffer");
        //display_buffer_status();
        sendResponse_gc_buffer_rm();
    }

    /*
    public static void display_buffer_status()
    {
        System.out.println("\nSHOWING BUFFER STATUS:");
        System.out.println("GC's CM Buffer: " + gc_buffer_cm);
        System.out.println("GC's RM Buffer: " + gc_buffer_rm);
        System.out.println("GC's internal process queue: " + internal_process_queue);
        System.out.println("process_var: " + process_var);
        System.out.println("CM's input buffer: " + cm_buffer_gc);
        System.out.println("RM's input buffer: " + rm_buffer_gc + "\n");
    }
    */

}